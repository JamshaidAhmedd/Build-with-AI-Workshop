from flask import Flask, request, render_template
from dotenv import load_dotenv
from PIL import Image
import os
import google.generativeai as genai
import io
import base64

# Load environment variables
load_dotenv()

# Configure Generative AI model
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-pro-vision")

app = Flask(__name__)

# Function to get Gemini response
def generate_image(input, image):
    if input != "":
        response = model.generate_content([input, image])
    else:
        response = model.generate_content(image)
    return response.text

# Function to convert image to base64 string
def image_to_base64(image):
    buffered = io.BytesIO()
    image.save(buffered, format="PNG")
    return base64.b64encode(buffered.getvalue()).decode('utf-8')


@app.route('/', methods=['GET', 'POST'])
def index():
    response = None
    image_data = None
    if request.method == 'POST':
        input_prompt = request.form.get('input')
        file = request.files.get('file')
        if file:
            image = Image.open(file.stream)
            image_data = image_to_base64(image)
            response = generate_image(input_prompt, image)
    return render_template('vision.html', response=response, image_data=image_data)

if __name__ == '__main__':
    app.run(debug=True)
