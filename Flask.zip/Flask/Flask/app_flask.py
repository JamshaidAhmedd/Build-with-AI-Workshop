from flask import Flask, request, render_template
from dotenv import load_dotenv
import os
import google.generativeai as genai

# Load environment variables
load_dotenv()

# Configure Generative AI model
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
model = genai.GenerativeModel("gemini-pro")

app = Flask(__name__)

# Function to get Gemini response
def get_gemini_response(question):
    response = model.generate_content(question)
    return response.text

@app.route('/', methods=['GET', 'POST'])
def index():
    response = None
    if request.method == 'POST':
        question = request.form['input']
        response = get_gemini_response(question)
    return render_template('app.html', response=response)

if __name__ == '__main__':
    app.run(debug=True)
